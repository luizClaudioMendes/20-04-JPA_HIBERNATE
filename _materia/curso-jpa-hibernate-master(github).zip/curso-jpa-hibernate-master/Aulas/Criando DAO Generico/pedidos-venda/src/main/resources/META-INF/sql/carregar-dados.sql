insert into pedido (referencia, data_venda, valor_total, entrega) values ("Rio de Janeiro", "2014-08-07", 200, "REALIZADA");
insert into pedido (referencia, data_venda, valor_total, entrega) values ("Ribeirão Preto", "2014-08-08", 240, "REALIZADA");
insert into pedido (referencia, data_venda, valor_total, entrega) values ("Belo Horizonte", "2014-08-09", 325, "REALIZADA");
insert into item_pedido (descricao, quantidade, valor, codigo_pedido) values ("Sabonete Líquido", 50, 2, 1);
insert into item_pedido (descricao, quantidade, valor, codigo_pedido) values ("Shampoo", 25, 4, 1);
insert into item_pedido (descricao, quantidade, valor, codigo_pedido) values ("Churrasqueira elétrica", 240, 1, 2);
insert into item_pedido (descricao, quantidade, valor, codigo_pedido) values ("Monitor", 325, 1, 3);