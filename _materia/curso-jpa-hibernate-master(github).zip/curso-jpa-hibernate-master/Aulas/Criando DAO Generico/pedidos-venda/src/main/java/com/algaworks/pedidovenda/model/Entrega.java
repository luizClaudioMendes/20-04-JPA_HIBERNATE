package com.algaworks.pedidovenda.model;

public enum Entrega {

	PENDENTE,
	REALIZADA
	
}
