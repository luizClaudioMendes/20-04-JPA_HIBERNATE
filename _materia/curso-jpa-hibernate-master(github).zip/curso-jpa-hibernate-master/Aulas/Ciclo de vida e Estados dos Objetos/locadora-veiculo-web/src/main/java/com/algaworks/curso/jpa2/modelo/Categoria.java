package com.algaworks.curso.jpa2.modelo;

public enum Categoria {

	HATCH_COMPACTO,
	HATCH_MEDIO,
	SEDAN_COMPACTO,
	SEDAN_MEDIO,
	SEDAN_GRANDE,
	MINIVAN,
	ESPORTIVO,
	UTILITARIO_COMERCIAL
	
}
