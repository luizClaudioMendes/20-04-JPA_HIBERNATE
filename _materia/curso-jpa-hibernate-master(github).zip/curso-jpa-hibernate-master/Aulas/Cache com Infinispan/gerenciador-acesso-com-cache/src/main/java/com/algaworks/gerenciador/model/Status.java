package com.algaworks.gerenciador.model;

public enum Status {

	ATIVO,
	INATIVO;
	
}
