package com.algaworks.curso.jpa2.service;

public class NegocioException extends Exception {

	public NegocioException(String message) {
		super(message);
	}
	
}
